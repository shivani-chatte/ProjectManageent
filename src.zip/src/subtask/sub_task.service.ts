import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { projectassign } from 'src/Entity/projectassign.entity';
import { subtaskassign } from 'src/Entity/subtaskassign.entity';
import { subtask } from 'src/Entity/sub_task.entity';

import { task } from 'src/Entity/task.entity';
// import { registration } from 'src/registration.entity';
import { createQueryBuilder, Repository } from 'typeorm';



@Injectable()
export class SubTaskService {
    constructor(
        @InjectRepository(subtask)
        private readonly subtaskRepository: Repository<subtask>,
        @InjectRepository(task)
        private readonly taskRepository: Repository<task>
    ){}

    
    // // <------------------create and save sub task--------------------------------------- >         
    async Add(subtask,task:task){
      let subtasks=await this.subtaskRepository.save(subtask);
      subtask.registrationid.forEach(async element => {
        console.log(subtask.id);
         let projectInfo=new subtaskassign()
         projectInfo['subtaskId']=subtask.id;
         projectInfo['registrationId']=element
          let userProj=await this.subtaskRepository.save(projectInfo);
        console.log(userProj)
         
      });
    }
  
    async gettaskById(id): Promise<task>{
      let task=  await this.taskRepository.findOne(id, {relations :['subtasks']});
      
      // if(!task){
      //   throw new NotFoundException(`${id} is not valid user type`)
      // }
      return task;
    }

   


    // <-----------------------------find subtask by using taskid---------------------------------------- >// 
    async findsubtask(task_id:number){
      
      
      const subtask = await createQueryBuilder("subtask") .where("task_id = :task_id",{task_id}).getMany()
      return subtask;
   }

     //------------------------------------Get all subtask---------------------------------------------//
     async findsubtasks(){
      await createQueryBuilder("subtask") .where("status = :status",{status:0}).getMany()
      const subtask = await this.subtaskRepository.find({ relations: ["tasks"] });
      
      return subtask
   }

   // <-----------------------------update  subtask---------------------------------------------- --->//
   async update(id: number, user: subtask
    ){
    const subtasks = await this.subtaskRepository.findOne(id, { relations: ["tasks"] });
    if(subtasks.status==1){
      throw new NotFoundException(`${id} is not exist`)
    }
  
     await this.subtaskRepository.update(id, user);
     let msg= "updated successfully"
         return msg;
   
  }


// <-----------------------------Delete subtask-------------------------------------------- > 
async delete(id: number){
  const subtasks = await this.subtaskRepository.findOne(id, { relations: ["tasks"] });
  if(!subtasks){
    throw new NotFoundException(`${id} is not exist`)
  }
  subtasks.status = 1
  return await this.subtaskRepository.update(id, {
    ...(subtasks.status && { status: 1 })});
}


async select(id){
  return await this.taskRepository
      .createQueryBuilder('t')
      .leftJoinAndSelect('t.taskassigns','pa')
      .leftJoinAndSelect('pa.registrations','r')
      .where({ id })
      .getOne();
    }
}



import { Body, Injectable, NotFoundException, Param, Post, Put } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { from, Observable } from 'rxjs';
import { projectassign } from 'src/Entity/projectassign.entity';
import { Projectinfo } from 'src/Entity/project_info.entity';
import { technologyassign } from 'src/Entity/technologyassign.entity';
//import { projectassign } from 'src/Entity/projectassign.entity';

import { Connection, createQueryBuilder, DeleteResult, Repository } from 'typeorm';

@Injectable()
export class ProjectinfoService {


    constructor(
        @InjectRepository(Projectinfo)
        private projectinforepository: Repository<Projectinfo>,
        @InjectRepository(projectassign)
        private projectassignRepository: Repository<projectassign>,
        @InjectRepository(technologyassign)
        private techologyassignRepository: Repository<technologyassign>
    ) { }

 //  <--------------------------addproject------------------------------------------->
 async createreport(post){
                 let projectinfo = new Projectinfo()
                 projectinfo['ProjectName'] = post.ProjectName
                // projectinfo['ProjectTechnology'] = post.ProjectTechnology
                 //projectinfo['ProjectResources'] = post.ProjectResources
                 projectinfo['VenderName'] = post.VenderName
                 projectinfo['Email'] = post.Email
                 projectinfo['MobileNo'] = post.MobileNo
                 projectinfo['CompanyName']=post.CompanyName
                 projectinfo['ProjectDurationMonth']=post.ProjectDurationMonth
                 projectinfo['ProjectDurationDay']=post.ProjectDurationDay
                 projectinfo['CreatedAt']=post.CreatedAt
                 projectinfo['EndAt']=post.EndAt
                 projectinfo['ProjectScope']=post.ProjectScope
    let project=await this.projectinforepository.save(post)
    console.log(post['registrationId'])
    
    // for(let element of post.registrationId){
    //     console.log(element)
        
    // }
    post.registrationId.forEach(async element => {
       console.log(project.id);
        let projectInfo=new projectassign()
        projectInfo['projectinfoId']=project.id;
        projectInfo['registrationId']=element
         let userProj=await this.projectassignRepository.save(projectInfo);
       // console.log(userProj)
        
    });
    post.technologyId.forEach(async element => {
        console.log(element);
        let projectInfo=new technologyassign()
        projectInfo['projectinfoId']=project.id;
        projectInfo['technologyId']=element
         let techProj=await this.techologyassignRepository.save(projectInfo);
        //console.log(techProj)
        
    });
    return project


}




//async createproject(projectinfo:Projectinfo) {

//     let users = project.registrationId
//     let tech = project.technologyId
//     users.forEach(uelement => {

//         // let tech = project.technologyId
         //tech.forEach(element =>{
            // // let projectinfo = new Projectinfo()
            // projectinfo['ProjectName'] = projectinfo.ProjectName
            // projectinfo['ProjectTechnology'] = projectinfo.ProjectTechnology
            // projectinfo['ProjectResources'] = projectinfo.ProjectResources
            // projectinfo['VenderName'] = projectinfo.VenderName
            // projectinfo['Email'] = projectinfo.Email
            // projectinfo['MobileNo'] = projectinfo.MobileNo
            // projectinfo['CompanyName']=projectinfo.CompanyName
            // projectinfo['ProjectDuration']=projectinfo.ProjectDuration
            // projectinfo['ProjectScope']=projectinfo.ProjectScope
             //['registrationId'] = uelement
            // projectinfo['technologyId'] = element

        
          //  return await this.projectinforepository.save(projectinfo)
//         });
        
//   });
//}
    //<-------------------------------view one project-------------------------------->

async getprojectbyId(id:number):Promise<Projectinfo>{
    const found= await this.projectinforepository.findOne(id,{relations:['projectassigns','technologyassigns']});
    
  if(!found){
    throw new NotFoundException('data not found');
  }
  return found;
  }


//     //<-------------------------------view one project-------------------------------->

//    async findOnePosts(id: number) {
//         const ProjectAssign = await this.projectinforepository.find({ relations: ["projectassigns",,"technologyassigns"] });
//         return ProjectAssign

//        // return from(this.projectinforepository.findOne(id));

//     }
     //<-------------------------------view project----------------------------------->

     async findAllPosts() {
        await createQueryBuilder("Projectinfo").where("status=:status",{status:0}).getMany()
        const project=await this .projectinforepository.find({relations:["projectassigns","technologyassigns"]});
        return project
    }

      //<---------------------------------edit project--------------------------------->

    async updateProject(id: number, post: Projectinfo) {
        const projects=await this .projectinforepository.findOne(id,{relations:["projectassigns","technologyassigns"]});
        if(projects.status==1){
            throw new NotFoundException(`${id}is not exist`)
        }


         await this.projectinforepository.update(id, post)
         let msg= "updated successfully"
         return msg;
    }
    
       //<-------------------------------deleteproject----------------------------------->

    async deleteproject(id: number) {
        const project = await this.projectinforepository.findOne(id);
        if (!project) {
            throw new NotFoundException(`${id} is not exist`)
        }
        project.status = 1
        return await this.projectinforepository.update(id, {
            ...(project.status && { status: 1 })
        });
    }
    async select(id){
        return await this.projectinforepository
        .createQueryBuilder('p')
        .leftJoinAndSelect('p.tasks','t')
        .leftJoinAndSelect('t.subtasks','st')
        .leftJoinAndSelect('st.registrations','r')
        .where({ id })
        .getOne();
      
      }



}





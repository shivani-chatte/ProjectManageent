import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { registration } from "./registration.entity";
import { subtask } from "./sub_task.entity";

@Entity()
export class history{
    @PrimaryGeneratedColumn()
    id:number;

    @ManyToOne(() => subtask  , subtasks  => subtasks .historys)
    @JoinColumn({name: "subtask_id"})
    subtasks: subtask[];

    @ManyToOne(() => registration  , registrations  => registrations.historys)
    @JoinColumn({name: "olduser_id"})
    registrations: registration[];

    @ManyToOne(() => registration  , regs  => regs.his)
    @JoinColumn({name: "newuser_id"})
    regs: registration[];

    @ManyToOne(() => registration  , Reg  => Reg.His)
    @JoinColumn({name: "admin_id"})
    Reg: registration[];


}
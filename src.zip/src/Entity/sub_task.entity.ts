import { Column, Entity, JoinColumn, ManyToOne, OneToMany, OneToOne, PrimaryGeneratedColumn } from "typeorm";
import { IsString,IsInt, IsNotEmpty } from 'class-validator';
import { task } from "./task.entity";
import { history } from "./history.entity";
import { registration } from "./registration.entity";
import { category } from "./category.entity";
import { priority } from "./priority.entity";
import { subtaskassign } from "./subtaskassign.entity";



@Entity()
export class subtask {

@PrimaryGeneratedColumn()
//@IsInt()
//@IsNotEmpty()
id: number;

 @Column()
 //@IsString()
 //@IsNotEmpty()
 sub_task: String;

 @Column()
 //@IsString()
 //@IsNotEmpty()
 user_name: string;

 @Column({nullable:true})
 description:string;

 @Column({nullable:true})
 start_date:Date;

 @Column({nullable:true})
 end_date:Date;

 @Column({nullable:true})
 Duration:number;

 @Column({nullable:true})
 totaltime:number;

@Column({default:0})
status:number;


 @Column({nullable:true})
 task_id:number;

 @Column({nullable:true})
 registrationid:number;

 @Column({nullable:true})
 category:number;

 @Column({nullable:true})
 priority:number;

 @OneToMany(() => subtaskassign,subtaskassigns => subtaskassigns.subtasks)
     subtaskassigns: subtaskassign[];




 @ManyToOne(() => task ,tasks => tasks.subtasks)
@JoinColumn({name:"task_id",referencedColumnName:"id"})
tasks:task[];

@OneToMany(() => history , historys  => historys.subtasks)
historys: history[];

@ManyToOne(() => registration ,registrations => registrations.subtasks)
@JoinColumn({name:"registrationid",referencedColumnName:"id"})
registrations:registration[];

@ManyToOne(() => category , categorys => categorys.subtasks)
@JoinColumn({name: "category"})
categorys: category[];

@OneToOne(()=> priority, prioritys =>prioritys.subtasks)
@JoinColumn({name:"priority",referencedColumnName:"id"})
prioritys:priority[];







}
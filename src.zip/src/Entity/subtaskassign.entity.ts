import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { registration } from "./registration.entity";
import { subtask } from "./sub_task.entity";

@Entity()
export class subtaskassign{
    @PrimaryGeneratedColumn()
    id:number;

    @Column({nullable:true})
    subtaskId:number;

    @Column({nullable:true})
    registrationId:number;


    @ManyToOne(()=>subtask,(subtasks)=>subtasks.subtaskassigns)
     @JoinColumn({name:"subtaskId",referencedColumnName:"id"})
    subtasks:subtask[]

    @ManyToOne(()=>registration,(registrations)=>registrations.subtaskassigns)
    @JoinColumn({name:"registrationId",referencedColumnName:"id"})
   registrations:registration[]


}